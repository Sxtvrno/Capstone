#!/bin/bash
# Install PostgreSQL development libraries
sudo dnf install -y postgresql15-devel
