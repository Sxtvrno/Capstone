# Deploy Back (FastAPI + asyncpg + Django settings) to AWS Elastic Beanstalk

## Prereqs

- Use a Postgres database (Amazon RDS). Collect env vars: DB_NAME, DB_USER, DB_PASSWORD, DB_HOST, DB_PORT.
- Email SMTP creds (optional): SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS.
- Security: DJANGO_SECRET_KEY, DJANGO_ALLOWED_HOSTS, FRONTEND_ORIGINS, URL_BACK.

## Files added

- `Procfile` to run Gunicorn with Uvicorn worker.
- `.ebextensions/01_env.config` to define environment variables (edit in console if you prefer).
- `.ebextensions/02_packages.config` for system packages.
- `.ebignore` to trim upload.

## Create EB app (Python platform)

1. Zip the contents of the `Back/` folder (including `requirements.txt`, `Procfile`, `.ebextensions/`).
2. In AWS Elastic Beanstalk, create a new application and environment (Web server, Python 3.x).
3. Upload the zip and deploy.
4. In Configuration -> Software, set Environment properties:
   - DJANGO_SETTINGS_MODULE=Back.settings
   - DJANGO_DEBUG=False
   - DJANGO_SECRET_KEY=<secret>
   - DJANGO_ALLOWED_HOSTS=<your-eb-domain,custom-domain>
   - FRONTEND_ORIGINS=https://<your-cloudfront-domain>
   - URL_BACK=https://<your-eb-domain or custom backend domain>
   - DB_NAME, DB_USER, DB_PASSWORD, DB_HOST, DB_PORT
   - SMTP\_\* if needed

## Database

- Security groups: allow EB instance to reach RDS on 5432.
- Apply migrations if using Django models; this project accesses DB via asyncpg, ensure schema exists (see `db.sql`).

## Health

- App listens on port 8000 (Gunicorn) and exposes `/health` for checks.

## Notes

- After deploy, update Front `.env.production` with the EB URL and rebuild/redeploy the Front to CloudFront.
